class TNormal:
    x=0
    y=0
    z=0


    def getX(self):
        return self.x

    def setX(self, x):
        self.x=x

    def getY(self):
        return self.y

    def setY(self, y):  
        self.y=y

    def getZ(self):
        return self.z
    
    def setZ(self, z):
        self.z=z