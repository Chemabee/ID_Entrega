Ejecución del programa: $ python main.py Esfera.asc

Para cerrar el programa pulsar tecla 'esc'.

Para aplicar un material aleatorio pulsar tecla 'r' o 'R'.

Por defecto la esfera no tiene un material asignado, tras pulsar la tecla 'r' o 'R' se escogerá un material.
